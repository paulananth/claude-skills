# Aladdin Research — Research Management Solution

## Overview
Aladdin Research is the centralized research management tool used by internal and external Aladdin clients to store, manage, and share investment research and data.

## Core Capabilities

### For Research Analysts
- Publish and organize investment research notes on entities in investible universe or macro themes/topics
- Maintain active ratings and commentary on coverage universe entities
- Research managers generate reports on: analyst coverage assignments, recommendation history

### For Portfolio Managers
- Consume research directly within Aladdin Research
- Receive email notifications and subscriptions based on research note attributes
- Search across research notes for specific themes and topics
- Comment and start dialog with research analysts

### Cross-Application Integration
- Aladdin Research data accessible in **Explore**
- Side-by-side views: security/portfolio risk & return data + research data (analyst recommendations)

## Key Workflows
1. Analyst publishes/maintains research notes and ratings
2. PM subscribes to relevant research notifications
3. PM searches and consumes research within the platform
4. PM comments / collaborates with analysts
5. Research data surfaced in Explore alongside risk/performance data

## Home Tab
- Curated widget list for staying updated on research notes and investment opinions
