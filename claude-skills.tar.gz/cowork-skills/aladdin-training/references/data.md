# Aladdin Data — SecurityMaster & Data Architecture

---

## Overview
Aladdin's data layer underpins all analytics and workflows. Data quality is foundational to the investment lifecycle. Key data domains: Security, Issuer, Index/Risk, Equity Fundamentals, Economic.

---

## Security Data Management

### Market Data Providers
- **Refinitiv** and **ICE** are primary market data providers for security data
- Auto-review process for standardized securities
- Security review workflow managed in **SecurityMaster**

### SecurityMaster
- Central application for security data management
- **Two-level classification scheme:** Security Group + Security Type
- Validation against external sources
- Trades Monitor Dashboard within SecurityMaster
- Built-in Aladdin Help feature with documentation and asset class guides

### Security Review Process
- Trades Monitor Dashboard tracks securities needing review
- Two-level classification: Security Group & Security Type
- Validation against external data sources
- Documentation and help resources available within the tool

---

## Issuer Data
- Centralized issuer data maintenance
- **Parent/Child relationships** (issuer tree structure)
- Modifications made at the issuer level
- Users can request changes to the issuer tree

---

## Index and Risk Data
| Data Type | Details |
|---|---|
| Index Positions & Prices | Used for benchmark tracking and performance |
| Sector & Country Classifications | Applied across risk and exposure analytics |
| Price Hierarchy (Waterfall) | Hierarchical pricing logic for security valuation |
| Active Exposures | Calculated from live positions |
| Risk Computation | Drives analytics in Explore and Green Package |

---

## Equity Fundamentals & Corporate Actions
| Data Type | Source |
|---|---|
| Financial Statements | Worldscope |
| Earnings Estimates & Ratios | Worldscope |
| Corporate Actions | Multi-source workflow |

---

## Economic Data
| Data Type | Role |
|---|---|
| Yield Curves | Fixed income pricing & risk |
| Spread Curves | Credit spread analytics |
| Volatility Curves | Options and derivatives analytics |
| FX Rates | Currency risk analytics |

---

## eFront Integration (Whole Portfolio View)

### Data Flow
- eFront (private markets) → Aladdin (public markets)
- Combined data surfaced in **Explore** reporting application
- Enables exposure, risk, stress testing, and performance analysis across public + private

### Supported Analysis in WPV
- Combined exposure views
- Risk analytics (public + private)
- Stress testing
- Performance analysis

---

## Key Data Concepts

| Term | Definition |
|---|---|
| Price Waterfall | Hierarchical priority for selecting security prices |
| Security Group | First level of Aladdin's two-level security classification |
| Security Type | Second level of Aladdin's two-level security classification |
| Issuer Tree | Parent/child hierarchy for issuer relationships |
| Worldscope | Data provider for equity fundamentals (financials, estimates) |
| Refinitiv | Market data provider for security pricing |
| ICE | Market data provider for security pricing |
| Green Package | SOD analytics package computed from all Aladdin data inputs |
