# Risk Analytics — Explore Risk Workflows

## Overview
Aladdin's risk analytics are primarily accessed through **Explore**. The platform supports both analytical and historical VaR methodologies, factor-based attribution, and stress testing.

## Core Risk Capabilities

### Value at Risk (VaR)
- Analytical VaR and Historical VaR available
- Adjust parameters in Analytical VaR or Risk Contribution views
- Attribute VaR changes to factors and individual securities
- Analyze historical trends of factor model measures

### Factor-Based Risk
- Factor model measures with trend analysis
- Attribute risk bets to realized returns
- Risk contribution decomposition by factor and security

### Stress Testing
- Market-driven scenario analysis
- Assess impact of hypothetical portfolio changes on risk measures
- Available via What-if function in Explore

### What-if Risk Modeling
- Model hypothetical portfolio composition changes
- Assess impact on: risk, analytics, and performance
- Five use cases: sector reallocation, FoF modeling, pre-trade analysis, custom benchmark, new portfolio creation

## Workflow for Risk Managers
1. Access risk analytics in Explore (methodology preface)
2. Adjust VaR parameters (Analytical VaR or Risk Contribution)
3. Attribute key risk measure changes to factors and securities
4. Analyze historical trends of factor model measures
5. Attribute risk bets to realized returns
6. Run what-if modeling exercises; assess impact on risk measures
7. Export data to Excel for further manipulation

## Key Terms
| Term | Definition |
|---|---|
| VaR | Value at Risk — statistical measure of potential loss |
| Analytical VaR | VaR calculated using factor model / parametric method |
| Risk Contribution | Decomposition of total portfolio risk by factor or security |
| Factor Model | Model decomposing returns/risk into systematic factor exposures |
| Stress Test | Scenario-based analysis of portfolio under hypothetical market conditions |
| Green Package | SOD analytics baseline from which intraday risk is layered |
