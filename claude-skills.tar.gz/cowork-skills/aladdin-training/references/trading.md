# Trading — Dashboard, TradeEntry, AladdinView

---

## Dashboard

### Overview
Dashboard is the primary workflow tool for traders on Aladdin. It contains monitors for the full order lifecycle and supports both Fixed Income and Equity trading desks.

### Primary Workflow Monitors
| Monitor | Purpose |
|---|---|
| Trader Orders | View and manage orders raised by PMs |
| Placements | Track orders placed to market/brokers |
| Trades Monitor | Monitor executed trades |

### Additional Capabilities
- Add widgets for market data and trade data
- Customize monitors with filters and alarms
- Share layouts across trading desks
- Automation capabilities for order processing
- Generate ad-hoc trade reports
- Aladdin's connectivity to external trading platforms

### Workflow (all asset classes)
1. Review and shape orders raised by portfolio managers
2. Assess market color using built-in widgets and Aladdin data
3. Place orders to market from Dashboard
4. Monitor executions and post trades
5. Manage commissions
6. Take advantage of automation capabilities
7. Generate ad-hoc trade reports

---

## TradeEntry

### Overview
TradeEntry is used for trade posting and security creation. Supports money market security creation on the fly via Smartcuts.

### Money Market Smartcuts
| Smartcut | Securities Covered |
|---|---|
| CASH | Bank Deposits, CPs, CDs, TDs, Tri-Party Repos |
| REPO | Bilateral Repos |

**Transaction types:**
- REPO / REV REPO → bilateral repos
- BUY / SELL → all other Money Market assets

### Key Workflows
- Create money market securities on the fly
- Post trades after execution
- Send positions from PfM line items to TradeEntry

---

## AladdinView

### Overview
AladdinView is the reporting application used in conjunction with Dashboard for trade reporting and post-trade analysis. Used by both Fixed Income and Equity traders.

---

## Financing Trader

### Overview
Tool for collateral-driven financing workflows (repo/reverse repo). Used by Money Markets teams to manage collateral inventory alongside Portfolio Monitor.

### Key Capabilities
- Collateral-driven workflow for repo/financing
- Monitor cash and collateral inventory
- Identify financing opportunities and raise orders

---

## Asset Class Trading Specifics

### Fixed Income Trading
- Full order lifecycle via Dashboard
- External trading platform connectivity
- Market color data within Aladdin to support execution decisions

### Equity Trading
- Full order lifecycle via Dashboard
- External trading platform connectivity
- Commission management

### Money Markets Trading
- Security creation on the fly (TradeEntry Smartcuts)
- Financing opportunity identification
- Post-trade repo activities (Turns, Pair Offs — during 48-hour day)
- Cash and collateral monitoring via PfM + Financing Trader
