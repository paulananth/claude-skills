# Operations — Reconciliation, Trade Ops, Derivatives, Corporate Actions, Unit Dealing

---

## Asset Reconciliation

### Overview
Reconcile positions in Aladdin against external sources (custodian, accounting system, fund administrator, third parties) through customizable rule sets.

### Primary Applications
| Application | Role |
|---|---|
| Dashboard | Monitor and manage reconciliation exceptions in real time |
| ART (Aladdin Recon Tool) | Run reconciliations and produce reports on an ad-hoc basis |
| Align | Ruleset management for reconciliation |
| Process Profile Manager (PPM) | Review and configure reconciliation configurations |
| SecurityMaster | Referenced during reconciliation workflows |
| AladdinView | Reporting support |

### Key Capabilities
- Reconcile positions against external sources
- Manage exceptions in Dashboard
- Re-run or update historical reconciliations ad-hoc in ART
- Ruleset management in Align

---

## Cash Reconciliation

### Overview
Daily process of reconciling Aladdin's cash balance and activity to custodian bank statements. Validates the settled cash balance in Aladdin — the foundation of the spendable balance provided to the front office. Cash publishing = validation of balances by specialists before delivery to front office. Highly automated with configurable tolerances.

### Primary Applications
| Application | Role |
|---|---|
| Dashboard | Monitor cash recon and publishing activity (Traffic Light icon on Genie) |
| CashMaster | Core cash reconciliation application |
| Align | Reconciliation ruleset management |
| CashEntry | Supplementary cash entry |
| AladdinView | Reporting |
| Portfolio Monitor | Cash monitoring support |
| Capital Flows Entry | Capital flow management |
| Ledger Maintenance | Ledger support |
| ADAM | Additional reference/analytics |

### SWIFT Message Formats
- **MT950, MT940** — cash statement message types consumed in cash reconciliation

### Key Process
1. Custodian sends cash statement (MT950/MT940)
2. Aladdin matches cash activity vs. custodian
3. Exceptions flagged on Dashboard
4. Cash Reconciliation Specialist validates and publishes balances
5. Validated cash balance delivered to front office

---

## Trade Operations

### Overview
End-to-end post-trade operations covering trade confirmation, notification, and settlement across asset classes. STP-first with exception handling on Dashboard.

### Three Core Workflows

#### Trade Confirmation
- Electronic trade matching across asset classes and third-party platforms
- Confirms monitor via Dashboard; STP workflow
- Exceptions handling in confirms monitor; mismatch scenario handling
- Broker-level configuration setup
- Tracking via AladdinView

#### Trade Notification
- Full scope of trade notification/instruction formats
- Transmissions monitor in Dashboard; transmission statuses and error handling
- Portfolio-level trade routing rule setup
- Tracking via AladdinView

#### Trade Settlement
- STP via Settlement monitor; MT54Y SWIFT message consumption
- Trade fails tracking and exceptions handling
- Settlement monitoring in AladdinView

---

## Derivative Operations

### Overview
End-to-end collateral management for OTC derivatives, cleared derivatives, and ETDs (futures, options).

### Bilateral (OTC) Derivatives
- Setup: ISDA Master Agreements with CSA captured in Aladdin
- Margin calls: monitored via AcadiaSoft (automated, low-touch exception workflow)
- Collateral selection tool: pledges cheapest/most liquid position by haircut and position size
- Instructions sent via SWIFT
- Files deliverable to Tri-resolve for reconciliation

### Cleared Derivatives
- Reconciliations from clearing broker files: positions, trades, margin balances, settled/pending net margin
- Agreed calls: net margin trade auto-booked and instructed via SWIFT
- Disputed calls: underlying reconciliation detail viewable from Dashboard

### ETD / Initial Margin
- IM requirements from clearing brokers and CCPs reconciled vs. collateral pledged in Aladdin
- Collateral selection tool books collateral trade; instructed via SWIFT

### Key Features
- Collateral call monitoring and trade communication
- Legal agreement repository (ISDA/CSA terms)
- Daily margin call management
- Collateral optimization and eligibility validation
- Real-time reports from Dashboard; integrated substitution workflow

---

## Corporate Actions

### Applications
| Application | Icon | Role |
|---|---|---|
| Dashboard | Traffic Light | Real-time monitoring of corporate action events |
| Corporate Actions Manager | Checklist | Full event details: payout, options, event terms, narrative, prospectus |

---

## Unit Dealing

### Overview
End-to-end fund trade workflow: order raising → monitoring → estimated trade booking → confirmation. STP-first.

### Workflow
1. Raise and authorize fund order
2. Monitor via Dashboard: Orders, Placements, Trades monitors
3. Aladdin books **estimated trade** overnight while awaiting confirmation
4. Breaks investigated from Dashboard; order status updated as needed
5. Order tracked to trade confirmation via STP

### Required Configuration
- **Fund Admission Schedule (FAS)** — key data configuration enabling the fund trading workflow

---

## Mortgage Operations (MortgageBrowser Beta)

### Overview
Primary tool for day-to-day mortgage inventory and operations. Real-time: security, trade, and position updates auto-flow into views.

### Access & Views
- Launch via Genie; real-time toggle (top-right corner)
- Create workspaces by: portfolio, agency, coupon, term
- Views: pivot table or list; displays POOLS, TBAs, MULTIs

### TBA 48-Hour Day Workflow
| Process | Detail |
|---|---|
| Turns & Pair Offs | TBA relationships established and communicated to brokers |
| SELL TBA Allocations | Outbound EPNs generated and sent |
| BUY TBA Allocations | Inbound EPNs received and mapped |
| Deadline | All allocation communication required before **3pm** |

### Integration
- Send rows to: TradeEntry, Anser, SecurityMaster
- Trade Relationship Optimizer facilitates scale for TBA workflows

---

## Key Ops Terminology

| Term | Definition |
|---|---|
| ART | Aladdin Recon Tool — ad-hoc reconciliation and reporting |
| Align | Reconciliation ruleset management application |
| PPM | Process Profile Manager — configuration review tool |
| CashMaster | Core cash reconciliation application |
| AcadiaSoft | Third-party for bilateral derivatives margin call automation |
| Tri-resolve | OTC derivative reconciliation platform |
| ISDA/CSA | Master Agreement / Credit Support Annex for OTC derivatives |
| MT950/MT940 | SWIFT cash statement message formats |
| MT54Y | SWIFT settlement message format |
| STP | Straight-Through Processing |
| EPN | Electronic Pool Notification (mortgage TBA) |
| FAS | Fund Admission Schedule — unit dealing configuration |
| Estimated Trade | Overnight placeholder trade pending confirmation |
| TBA | To-Be-Announced mortgage security |
