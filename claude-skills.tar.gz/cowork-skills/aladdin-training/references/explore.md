# Explore — Reporting & Analytics

## Overview
Explore is Aladdin's flagship application providing a flexible, integrated framework for portfolio modeling, analysis, and reporting across exposures, risk analytics, stress testing, returns, and performance attribution — in both tabular and graphical formats, point-in-time and time-series.

## Access
- Launch via the **Genie toolbar** or the Aladdin Client site (Google Chrome)
- Enter a portfolio ticker, comma-delimited list of tickers, or open a pre-existing workspace

## Core Capabilities

### Workspace
- Fully customizable layout: add/remove widgets, adjust portfolio-level settings
- Library of pre-canned report templates; search firm-built reports
- Save workspaces for future use; share with colleagues
- Batch reporting: generate reports across large lists of portfolios

### Analytics Available
| Category | Details |
|---|---|
| Exposures | Sector, country, duration, credit rating, issuer |
| Risk | VaR (analytical & historical), factor contributions, stress tests |
| Performance | P&L, returns, returns contribution; Brinson, factor-based, FI, multi-asset models |
| What-if | Hypothetical portfolio changes; pre-trade impact; scenario analysis |

## What-if Analysis in Explore
Five use cases covered in training:
1. Sector reallocation through a duration lens
2. Portfolio-level modeling for fund-of-funds
3. Point-in-time pre-trade analysis (adding a security)
4. Custom blended benchmark construction
5. Create new portfolios from scratch on the fly

**Modeling styles:** Different styles available for modeling in Explore; portfolios can be created from scratch within the tool.

## Whole Portfolio View (WPV) in Explore
- Combines public market data (Aladdin) with private market data (eFront)
- Data flows from eFront into Aladdin
- Reports combine public + private for: exposure, risk, stress testing, performance analysis

## Risk Analytics in Explore (Risk Manager workflows)
- Determine Value at Risk (VaR)
- Attribute VaR changes to factors and securities
- Analyze historical trends of factor model measures
- Attribute risk bets to realized returns
- Model what-if scenarios and assess impact on risk measures
- Export data to Excel

## Performance Analytics in Explore
Three measures for changes in investment value:
- **P&L** — absolute profit/loss
- **Returns** — percentage-based
- **Returns Contribution** — weighted contribution to portfolio return

Attribution models:
- **Brinson Approach** — allocation + selection effects (equities)
- **Factor-Based Approach** — factor model attribution
- **Fixed Income Models** — FI-specific attribution
- **Multi-Asset Approach** — cross-asset class attribution
