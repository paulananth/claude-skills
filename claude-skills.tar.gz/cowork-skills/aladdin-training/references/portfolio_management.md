# Portfolio Management — PfC & PortfolioMonitor

---

## Portfolio Construction (PfC)

### Overview
PfC is Aladdin's premier analytical order-modeling and order-raising tool. It functions as a PM "scratchpad" — PMs model orders and assess portfolio impact before posting downstream to traders for execution. PfC takes the Green Package analytics one step further by layering intraday orders and trades onto SOD GP data to show real-time exposures.

### Access
- Launch from the **Genie toolbar**
- Input: portfolios, portfolio groups, or indices; or open pre-existing workspaces

### Core Capabilities
| Capability | Details |
|---|---|
| Workspace config | Settings, views, zooming, locking functionality |
| Order modeling | Model orders; assess impact on portfolios before execution |
| Pre-trade compliance | What-if Compliance evaluation |
| Rebalancing | Rebalance to benchmarks or strategic indicators |
| Multi-fund management | Simplifies managing many funds at once |

### PfC for Passive Equity
- Exceptions and rules-based framework
- Equitize cash to reduce cash drag
- Rebalance using algorithms
- Portfolio Summary View: high-level tolerances, breach alerts, easy rebalance
- Country View: configurable for benchmark country analysis
- Efficiently identify non-benchmark names and restricted assets
- Equity ETF issuance workflows

### PfC for Active Fixed Income PMs
- Intraday view of fixed income portfolio
- Manage issuer and credit rating exposures
- Create allocation strategies
- Set up targets; rebalance against targets
- Hedge key rate duration profile
- Review issuer exposure vs. issuer limits
- Allocate fixed income security across several portfolios
- Track intraday changes to fixed income risk analytics

### PfC for Fund of Fund (FoF)
- Target-driven and systematic portfolio management
- Supports strategic and tactical asset allocation
- Multi-asset workflows at scale
- Create and use targets and strategies
- Look-through settings for underlying fund exposures
- Sector groups with custom aggregations
- Rebalance using algorithms

---

## PortfolioMonitor (PfM)

### Overview
PfM is Aladdin's portfolio management and trading application for monitoring intraday cash balances, P&L, and portfolio-level risk and currency exposures in real time. It takes SOD risk & analytics from the Green Package and layers on intraday trades and orders.

### Access
- Launch from the Genie toolbar
- Supports multi-portfolio & multi-currency views

### Core Capabilities
| Capability | Details |
|---|---|
| Workspace setup | Layouts, work pads, preference options |
| Cash monitoring | Intraday cash balances by currency |
| P&L monitoring | Real-time P&L tracking |
| Risk monitoring | Portfolio-level risk exposures intraday |
| Currency monitoring | FX exposures in real time |
| Targets | Create and manage cash, risk, and currency targets |
| Position Roller | Raise and model orders directly from PfM |

### PfM for Money Markets
- View currency exposures and cash balances on a go-forward basis
- Send line items to TradeEntry to raise as orders or trades via CASH or REPO smartcuts

---

## Key Concepts

| Term | Meaning |
|---|---|
| Green Package (GP) | Start-of-day risk & analytics baseline |
| SOD | Start of Day — baseline position data |
| Intraday layering | PfC/PfM add live trades/orders on top of SOD GP |
| Gold copy workflow | Authoritative portfolio state management workflow in PfM |
| Position Roller | Tool in PfM for raising/modeling orders from positions |
| What-if Compliance | Pre-trade compliance check within PfC |
