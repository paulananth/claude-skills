# Aladdin Accounting — Official Accounting, Portfolio Valuation & NAV Oversight

---

## Overview

Aladdin Accounting has two key offerings:
1. **Performance Accounting** — Portfolio Valuation, Fund Performance & NAV Oversight
2. **Official Accounting** — Accounting Book of Record (ABOR) on Aladdin

---

## Core Terminology

| Term | Definition |
|---|---|
| IBOR | Investment Book of Record — real-time, accurate, consolidated investment data supporting investment decision-making; the Aladdin platform itself |
| OBOR | Operational Book of Record — cohesive data source for all investment-related transactions (trades, payments, prices, corporate actions, derivatives); integrates with IBOR |
| ABOR | Accounting Book of Record — maintains official accounting records for an investment portfolio |
| Business Event | Any action or change impacting investment management (transactions, status changes); tracked in OBOR; initiates accounting events |
| Accounting Event | Occurrence recorded in financial statements via journal entry; involves monetary transactions; results in at least one debit and credit in a subledger |

---

## Official Accounting

### Overview
Foundational training; no prerequisites required. Covers concepts, terminology, workflows, data flow stages, and a simplified worked example (purchasing a security).

### Data Flow
- Single flow of data from front, middle, and back-office processes
- IBOR (Aladdin) + ABOR (Aladdin Accounting) = integrated solution, eliminating disparate system friction
- Built-in data quality checks at each stage; multi-basis, multi-currency accounting reports

### Clients
- Insurance companies, corporations, pensions, asset owners, asset managers

### Value Proposition
- Integrated IBOR and ABOR eliminates reconciliation between Aladdin and external accounting systems
- Consistent high-quality data throughout investment workflow
- Enables scale and control across the reporting lifecycle

---

## Portfolio Valuation & NAV Oversight

### Portfolio Valuation
- Calculates Net Asset Value (NAV) based on investment data for institutional and separate accounts
- Paired with official performance figure → client reporting and GIPS® process
- **Closed-book, locked workflow** — snapshot of data at a point in time (e.g., month-end)
- No reconciliation needed between Aladdin and external accounting systems
- Aladdin runs **60 quality controls** on data to ensure accuracy
- Single source of truth: Aladdin book of record
- Frequency: typically monthly

### NAV Oversight
- Exception-based workflow for reconciling data to the fund administrator
- Compares portfolio NAV on Aladdin vs. Fund Administrator's book of record
- Uses Aladdin Accounting engine + multi-bucket accounting data model
- Comparison on **T-1 basis**
- Frequency: can run daily
- Highly automated with configurable exceptions

### Applications Used
| Application | Role |
|---|---|
| Dashboard | Main workflow tool; Accounting Workflow Monitor and Accounting Exceptions Monitor |
| Accounting Portal | Five tabs: Home, Valuations, Reporting, Configuration, Maintenance; resolution guides per exception |
| AladdinView | Reporting support |
| TradeEntry | Valuation process support |
| ADAM | Additional reference |

### Key Workflows
- Close the books on Aladdin
- Compare external accountant valuation data vs. Aladdin Accounting valuations
- Manage valuation workflow on Dashboard
- Review reports in Accounting Portal
- Review valuations in the Portal
- Post adjustments to the ledger
- Use external tools for QC investigation
- Complete NAV oversight workflow

### Fund Performance & NAV Oversight
- Day-to-day and monthly calculations of Fund Performance and NAV
- Manage Fund Performance workflow and handle exceptions
- Accurate performance calculations and data source configuration

---

## Aladdin Trading — Full Investment Lifecycle Overview

### Overview (Aladdin_Trading.docx — foundational overview course)
Covers the complete investment management lifecycle end-to-end:

#### 1. Risk, Analytics & Reporting (Explore)
- Analytics and exposure monitoring
- Stress testing and what-if analysis
- Performance and attribution

#### 2. Portfolio Management (Portfolio Construction)
- Intraday portfolio views and order modeling
- Order generation with sophisticated targeting across portfolios
- Integration with compliance; connectivity with trading

#### 3. Order Management, Trade Execution & Operations (Dashboard)
- Order shaping: merging, crossing, splitting, modifying orders
- Intraday market color; connectivity to liquidity/execution venues
- STP to confirm and process trades; manage exceptions

---

## BQL — BlackRock Query Language

### Overview
BQL is Aladdin's query language for compliance rule coding. Used by Compliance Officers to configure investment compliance rules on Aladdin.

### Context
- Part of Aladdin's **Investment Compliance** offering
- Enables organizations to adhere to client, regulatory, and operational guidelines throughout the investment management lifecycle
- Supports comprehensive compliance workflow: rule setup → breach resolution

### BQL Components
- BQL statement components (structure and syntax)
- How to build and interpret BQL statements
- Relationship between Aladdin's data model and BQL
- Self-service resources available within Aladdin

### Example Syntax Concepts
- Pattern matching: e.g., capturing portfolio names beginning with a specific prefix (e.g., `TEST-DEM`)
- IN statement: `(v1, v2, v3)` — matching multiple values

### Use Case
- Compliance Officers code rules in BQL to define investment guideline constraints
- Rules feed into the compliance workflow for breach detection and resolution
