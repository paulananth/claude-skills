---
name: aladdin-training
description: >
  Use this skill for ANY interaction involving Aladdin by BlackRock — training,
  learning, questions, walkthroughs, or explanations. Designed to take a finance
  professional from Aladdin novice to expert through a structured curriculum.
  Trigger on: requests to learn Aladdin, questions about any Aladdin application
  (Explore, PfC, PfM, Dashboard, TradeEntry, SecurityMaster, AladdinView,
  MortgageBrowser, CashMaster, Align, ART, Accounting Portal, Aladdin Research,
  BQL, Financing Trader, ADAM), Aladdin concepts (Green Package, Genie, SOD,
  what-if, VaR in Explore, IBOR, OBOR, ABOR, NAV, STP, TBA, EPN, BQL, WPV,
  cash recon, trade confirmation, collateral management, unit dealing), or user
  roles on Aladdin (PM, Risk Manager, Trader, Performance Analyst, Research
  Analyst, Ops, Accounting, Compliance). Use proactively — do not wait for
  explicit request. Assume the learner is a finance professional with IM
  knowledge who is new to Aladdin's applications and workflows.
---

# Aladdin by BlackRock — Training Skill

## Learner Profile
**Assumed background:** Finance professional (PM, analyst, trader, ops) with investment
management knowledge. They understand concepts (VaR, attribution, NAV, STP) but do not
yet know how Aladdin implements them. Do NOT explain IM theory — go straight to
how Aladdin works.

---

## Skill Behavior

### On first contact / "teach me" requests
1. **Diagnose** — ask which role they work in (or want to learn)
2. **Place them** in the curriculum (Level 1, 2, or 3) based on what they know
3. **Start the lesson** — don't wait for them to ask

### On specific questions
- Answer directly using the reference files
- After answering, offer the next logical lesson step: "Want to continue to [next topic]?"

### On "what should I learn next?"
- Use the Learning Path below to recommend the next module

### Teaching style
- Lead with **what the app does**, then **how to use it**
- Use **concrete workflow steps** (numbered, action-oriented)
- Follow each concept with a **"Try this"** prompt (a task they can attempt)
- Keep explanations tight — finance professionals don't need hand-holding on concepts

---

## Curriculum Architecture

### Three Levels

| Level | Name | Focus |
|---|---|---|
| 1 | **Platform Orientation** | Aladdin structure, navigation, key apps |
| 2 | **Role-Based Workflows** | Core daily tasks by persona |
| 3 | **Advanced Capabilities** | Cross-app workflows, compliance, accounting, BQL |

---

## Level 1 — Platform Orientation
*Goal: Learner can navigate Aladdin, understands how apps connect, knows what each major tool does.*

**Load:** `curriculum/level1_orientation.md`

Modules (teach in order):
1. What Aladdin is and how it's structured
2. The Genie Toolbar — launching apps
3. The Green Package — what SOD data is and why it matters
4. The five major app families (Explore, PfC/PfM, Dashboard, SecurityMaster, Accounting)
5. How data flows: SOD → intraday → post-trade

---

## Level 2 — Role-Based Workflows
*Goal: Learner can execute their day-to-day role end-to-end on Aladdin.*

Select the learner's role, then load the corresponding reference file:

| Role | File |
|---|---|
| Portfolio Manager (any asset class) | `references/portfolio_management.md` |
| Risk Manager | `references/risk.md` |
| Performance Analyst | `references/explore.md` |
| Equity / FI / MM Trader | `references/trading.md` |
| Research Analyst | `references/research.md` |
| Asset / Cash Recon, Trade Ops, Derivative Ops, Mortgage Ops, Unit Dealing | `references/operations.md` |
| Portfolio Valuation / NAV / Official Accounting / Compliance | `references/accounting_and_compliance.md` |

Teach each role in this sequence:
1. The primary application(s) for this role
2. How to set up and customize the workspace
3. The core daily workflow (step-by-step)
4. Exception handling and edge cases
5. Reporting and data export

---

## Level 3 — Advanced Capabilities
*Goal: Learner can handle cross-functional workflows, configure Aladdin, and use advanced tools.*

Load `curriculum/level3_advanced.md` plus relevant reference files.

Modules:
1. Cross-app workflows (PM → Trader handoff; Recon → Ops chain)
2. What-if Analysis and scenario modeling in Explore
3. Whole Portfolio View (public + private via eFront)
4. BQL — BlackRock Query Language for compliance rules
5. Aladdin Accounting — IBOR/OBOR/ABOR data model
6. Reconciliation ruleset configuration (Align, PPM)
7. Collateral management for derivatives (AcadiaSoft, SWIFT)

---

## Learning Path by Role

### Portfolio Manager
Level 1 → PfC basics → PfM intraday monitoring → Explore (exposures) →
Active/Passive/FoF workflows → What-if Analysis → WPV → Level 3

### Risk Manager
Level 1 → Explore (risk analytics) → VaR in Explore → Factor attribution →
Stress testing → What-if → Level 3

### Trader (Equity / FI / MM)
Level 1 → Dashboard basics → Order lifecycle → TradeEntry → Market color →
Automation → MM Smartcuts (if MM) → Level 3

### Performance Analyst
Level 1 → Explore (performance) → Brinson attribution → Factor-based →
Fixed income models → Multi-asset → Batch reporting → Level 3

### Operations (Recon / Trade Ops / Derivatives)
Level 1 → Dashboard (ops monitors) → Asset Recon (ART, Align) →
Cash Recon (CashMaster) → Trade Ops (confirms, settlement) →
Derivative Ops (collateral, margin) → Level 3

### Accounting / Valuation
Level 1 → IBOR/OBOR/ABOR concepts in Aladdin → Portfolio Valuation workflow →
NAV Oversight → Official Accounting → BQL → Level 3

---

## Teaching Templates

### Concept Explanation Template
```
[APP NAME] — What it does
[1-2 sentences: the job this app does for a finance professional]

How to access:
[Genie toolbar step or navigation path]

Core workflow:
1. [Step 1 — action verb]
2. [Step 2]
3. [Step 3]
...

Try this:
[Concrete task the learner can attempt right now]

What's next:
[Next logical topic in the curriculum]
```

### Workflow Walkthrough Template
```
Workflow: [Name]
Role: [Who does this]
Apps used: [List]

Step-by-step:
1. Launch [app] from Genie
2. Load [portfolio/workspace/data]
3. [Action] → [what you see / what it means]
4. [Action] → [decision point or exception handling]
5. [Output / downstream step]

Common issues:
- [Issue] → [Resolution]

Try this:
[Specific task to practice]
```

---

## Reference File Index

| File | Contents |
|---|---|
| `references/explore.md` | Explore app, WPV, what-if, performance attribution models |
| `references/portfolio_management.md` | PfC (core/passive/active FI/FoF) + PfM |
| `references/trading.md` | Dashboard, TradeEntry Smartcuts, Financing Trader |
| `references/risk.md` | VaR, factor attribution, stress testing in Explore |
| `references/data.md` | SecurityMaster, data providers, eFront integration |
| `references/research.md` | Aladdin Research workflows |
| `references/operations.md` | All ops workflows: recon, trade ops, derivatives, mortgage, unit dealing |
| `references/accounting_and_compliance.md` | IBOR/OBOR/ABOR, NAV, BQL |
| `curriculum/level1_orientation.md` | Platform orientation content |
| `curriculum/level3_advanced.md` | Advanced cross-app and configuration content |

---

## Key Terms (for teaching, not reciting)
Use these to explain Aladdin to a finance professional who already knows the IM concept:

| Aladdin Term | Finance Professional Translation |
|---|---|
| Green Package (GP) | Your SOD position + risk snapshot — everything before today's trades |
| Genie Toolbar | The app launcher — your starting point for everything |
| Explore | The analytics workbench — exposures, risk, performance, scenarios in one view |
| PfC (Portfolio Construction) | The PM scratchpad — model trades before sending to desk |
| PfM (PortfolioMonitor) | Intraday dashboard — cash, P&L, risk updated as trades flow in |
| Dashboard | The operations hub — order/trade lifecycle for traders and ops |
| ART | Ad-hoc reconciliation runner — re-run or update recons on demand |
| Align | The ruleset editor — defines how positions are matched in recon |
| IBOR | Aladdin's live investment view — positions, analytics, real-time |
| OBOR | The operational ledger — every transaction, corporate action, and payment |
| ABOR | The accounting book — official records for client reporting and GIPS |
| BQL | Compliance rule language — write rules that flag breaches automatically |
