# Level 1 — Platform Orientation

*For: Finance professionals new to Aladdin. Assumes IM knowledge; no finance theory needed.*

---

## Module 1.1 — What Aladdin Is

### The One-Line Answer
Aladdin is BlackRock's operating system for investment management — it connects analytics, portfolio management, trading, operations, and accounting on a single platform.

### Why It Matters to You
Every role in an investment firm touches a different part of the investment lifecycle. Aladdin's design principle is that all those roles share the same data — there is no reconciliation between the PM's view and the trader's view. What the PM models in PfC is what the trader sees in Dashboard.

### The Investment Lifecycle on Aladdin
```
[Idea / Research]     → Aladdin Research, Explore
[Risk & Analytics]    → Explore (VaR, exposures, attribution)
[Portfolio Modeling]  → Portfolio Construction (PfC)
[Compliance Check]    → Compliance (BQL rules, what-if)
[Order to Trader]     → PfC → Dashboard
[Trade Execution]     → Dashboard, TradeEntry
[Post-Trade / Ops]    → Dashboard (confirms, settlement), Recon tools
[Accounting]          → Aladdin Accounting (IBOR → OBOR → ABOR)
```

**Try this:** Map your current role to one or two stages above. That's where your Level 2 training begins.

---

## Module 1.2 — The Genie Toolbar

### What It Is
The Genie toolbar is Aladdin's navigation bar — every application is launched from here. Think of it as your taskbar.

### Key Icons to Know
| Icon | Application | Who Uses It |
|---|---|---|
| Traffic Light | Dashboard | Traders, Ops, Recon, Accounting |
| Chart/Graph | Explore | PMs, Risk, Performance |
| Grid | Portfolio Construction (PfC) | PMs |
| Monitor | PortfolioMonitor (PfM) | PMs, Traders |
| Checklist | Corporate Actions Manager | Ops |
| Book | SecurityMaster | Data, Ops |
| Calculator | TradeEntry | Traders, Ops |

### How to Launch an App
1. Locate icon on Genie toolbar
2. Click → app opens
3. Enter portfolio ticker(s), or open a saved workspace

**Try this:** Identify which Genie icon corresponds to your primary daily tool.

---

## Module 1.3 — The Green Package (SOD Data)

### What It Is
The Green Package (GP) is Aladdin's start-of-day (SOD) analytics package. It is computed overnight and contains:
- All portfolio positions
- Risk analytics (VaR, factor exposures, duration, etc.)
- Performance data
- Benchmark comparisons

### Why It Matters
The Green Package is the **baseline** that PfC and PfM layer intraday trades on top of. When you see "SOD" anywhere in Aladdin, it refers to Green Package data.

### GP → Intraday Layering
```
Green Package (SOD)
    ↓ + intraday orders/trades
Portfolio Construction (PfC) → real-time exposure view
PortfolioMonitor (PfM) → real-time cash/P&L/risk
```

**Key implication:** If a trade was modeled in PfC but not yet executed, PfC shows it as a "what-if" layer on top of GP. Once the trader executes, PfM reflects it in real time.

**Try this:** Ask — "What time does the Green Package update at your firm?" This determines when your SOD analytics are fresh each morning.

---

## Module 1.4 — The Five App Families

### Family 1: Analytics & Reporting → Explore
- The most-used app on Aladdin
- Single workbench for: exposures, risk, performance, attribution, stress testing, what-if
- Used by: PMs, Risk, Performance Analysts
- Fully customizable workspace with widgets

### Family 2: Portfolio Management → PfC + PfM
- **PfC (Portfolio Construction):** PM's order-modeling scratchpad. Model trades, check compliance, send to trader.
- **PfM (PortfolioMonitor):** Intraday view of cash, P&L, risk, currency as trades flow in.
- Used by: All portfolio managers

### Family 3: Trading & Order Management → Dashboard + TradeEntry
- **Dashboard:** Trader's primary workflow — Trader Orders, Placements, Trades monitors.
- **TradeEntry:** Post trades; create securities on the fly (money markets).
- **AladdinView:** Reporting alongside Dashboard.
- Used by: Traders, Trade Ops

### Family 4: Operations & Reconciliation → Dashboard (Ops) + Recon Tools
- Dashboard is used by both traders AND ops — same app, different monitors
- **ART:** Aladdin Recon Tool for position/cash reconciliation
- **Align:** Ruleset configuration for recon
- **CashMaster:** Cash reconciliation
- **MortgageBrowser Beta:** Mortgage inventory and TBA operations
- Used by: Asset Recon, Cash Recon, Trade Ops, Derivative Ops, Mortgage Ops

### Family 5: Accounting → Aladdin Accounting + Accounting Portal
- **IBOR:** Aladdin's live investment view
- **OBOR:** Operational records (trades, payments, corporate actions)
- **ABOR:** Official accounting records for client reporting
- **Accounting Portal:** Five-tab hub for valuation, NAV, reporting, configuration
- Used by: Accounting, Valuation, NAV Oversight

---

## Module 1.5 — How Data Flows Through Aladdin

### The Full Data Chain
```
Security Data        → SecurityMaster (Refinitiv, ICE, Worldscope)
                              ↓
Overnight Processing → Green Package (SOD risk & analytics)
                              ↓
Intraday             → PfC layers orders → PfM reflects trades
                              ↓
Execution            → Dashboard (trader) → TradeEntry (post)
                              ↓
Post-Trade           → Confirms, Settlement, Recon (Dashboard ops monitors)
                              ↓
Accounting           → OBOR → ABOR (Aladdin Accounting)
                              ↓
Reporting            → Explore, AladdinView, Accounting Portal
```

### Key Integration Points
| From | To | What transfers |
|---|---|---|
| PfC (PM) | Dashboard (Trader) | Modeled orders posted for execution |
| Dashboard (Trader) | TradeEntry | Executed trades posted |
| TradeEntry | Accounting | Trade data flows into OBOR |
| eFront (private markets) | Explore | Private market data for WPV reports |
| Aladdin Research | Explore | Analyst ratings visible alongside risk/return data |

### What "Single Source of Truth" Means in Practice
There is no separate accounting system to reconcile against. The PM's position in PfC, the trader's view in Dashboard, and the accountant's view in Accounting Portal all draw from the same underlying data. Changes propagate in real time during the day; the Green Package re-computes them overnight.

**Try this:** Draw your firm's current data flow (systems → people → reports). Then map each step to an Aladdin equivalent using the chain above.

---

## Level 1 Completion Check

You're ready for Level 2 when you can answer:
1. What does the Green Package contain and when is it updated?
2. Which Genie icon launches your primary application?
3. What is the difference between PfC and PfM?
4. Where in the data chain does your role sit?
5. What does "intraday layering" mean in the context of PfC and PfM?

**Next step:** Move to Level 2 — load the reference file for your role.
