# Level 3 — Advanced Capabilities

*For: Aladdin users who are proficient in their role's core workflow and ready for cross-app, configuration, and advanced analytical capabilities.*

---

## Module 3.1 — Cross-App Workflows: PM → Trader Handoff

### Overview
The PM-to-trader workflow is the most critical cross-app integration in Aladdin. Understanding it end-to-end prevents operational breaks.

### Full Workflow
```
PM in PfC:
1. Load portfolio(s) into PfC
2. Model order (security, quantity, direction)
3. Run What-if Compliance → verify no guideline breaches
4. Post order downstream → order appears in Dashboard

Trader in Dashboard:
5. Order appears in Trader Orders monitor
6. Trader shapes order (merge, cross, split, modify)
7. Assesses market color via Dashboard widgets
8. Places order to market / execution venue
9. Monitors placements; receives execution fills

Post-Execution:
10. Trader posts trade in TradeEntry
11. Trade flows into PfM (PM sees intraday position update)
12. Trade flows into OBOR → overnight into Green Package
```

### Order Shaping Options (Dashboard)
| Action | When to Use |
|---|---|
| Merge | Combine multiple small orders into one block |
| Cross | Match buy/sell between two internal portfolios |
| Split | Break large order into smaller clips for execution |
| Modify | Change quantity, price limit, or instructions |

### Common Break Points
- PM posts order but compliance fails → PM must resolve in PfC before trader sees it
- Trader executes but trade not posted in TradeEntry → PfM won't update
- TradeEntry posting errors → escalate to Trade Ops for confirm/settlement resolution

---

## Module 3.2 — What-if Analysis in Explore (Advanced)

### Five Use Cases
| Use Case | What You're Modeling |
|---|---|
| Sector reallocation | Shift weight between sectors; view duration/risk impact |
| Fund-of-funds | Portfolio-level modeling for multi-fund exposure |
| Pre-trade analysis | Add a single security; see impact on risk and exposures |
| Custom blended benchmark | Build a composite benchmark; compare portfolio against it |
| Create portfolio from scratch | Build a hypothetical portfolio on the fly in Explore |

### Workflow: Pre-Trade Analysis in Explore
1. Open Explore → load portfolio
2. Open What-if panel
3. Select "Add security" → enter ticker and weight/quantity
4. Explore re-calculates exposures, VaR, and attribution with the hypothetical position
5. Compare "current" vs. "what-if" side-by-side
6. If satisfied → pass back to PfC to raise the actual order

### Key Modeling Styles in Explore
- **Point-in-time:** Snapshot analysis at a specific date
- **Leveling:** Adjust positions to a target level or weight
- **Scenario:** Apply a market shock to the portfolio

---

## Module 3.3 — Whole Portfolio View (WPV)

### Overview
WPV brings together public market data (Aladdin) and private market data (eFront) into a single view in Explore.

### Data Flow
```
eFront (private markets: PE, real estate, infrastructure, private credit)
    ↓ data feeds into Aladdin
Explore → combined public + private reporting
```

### What You Can Do in WPV
| Analysis Type | Public | Private | Combined |
|---|---|---|---|
| Exposure | ✓ | ✓ | ✓ |
| Risk | ✓ | ✓ | ✓ |
| Stress Testing | ✓ | ✓ | ✓ |
| Performance | ✓ | ✓ | ✓ |

### Practical Notes
- Private market data updates on eFront's schedule (not real-time like public)
- Report templates in Explore can be built to include both data sets
- eFront-sourced positions appear in the same workspace as public positions

---

## Module 3.4 — BQL: BlackRock Query Language

### What It Is
BQL is the language used to write investment compliance rules in Aladdin. Compliance Officers use it to define constraints that are checked automatically on every portfolio.

### Why It Exists
Investment guidelines (client mandates, regulatory limits, internal policies) are expressed in plain English but must be translated into machine-executable rules. BQL is that translation layer.

### BQL Statement Structure
A BQL statement has:
1. **Subject** — what is being measured (a security attribute, portfolio exposure, position)
2. **Operator** — the comparison (greater than, less than, equal to, IN, NOT IN)
3. **Value / threshold** — the limit or target

### Common Operators
| Operator | Syntax | Example Use |
|---|---|---|
| Pattern match | `STARTS WITH 'TEST-DEM'` | Match portfolio names |
| List match | `IN (v1, v2, v3)` | Match security type, rating, country |
| Greater than | `> 0.05` | Exposure limit breach |
| Less than | `< 0.02` | Minimum weight check |

### BQL in the Compliance Workflow
```
Compliance Officer writes BQL rule → rule saved in Aladdin
    ↓ runs automatically on each portfolio each night (or intraday)
Breach detected → alert surfaced in Dashboard compliance monitor
    ↓
Portfolio Manager → resolve breach (trade, waiver, or escalation)
```

### Self-Service Resources
Aladdin provides documentation and help features within the compliance rule configuration screens for reference while coding.

---

## Module 3.5 — Aladdin Accounting: The IBOR → OBOR → ABOR Chain

### The Three Books
```
IBOR (Investment Book of Record)
= Aladdin's live investment view
= Positions, analytics, real-time data supporting investment decisions
        ↓
OBOR (Operational Book of Record)
= Every transaction, corporate action, payment, and derivative processing
= Built-in data quality checks at each stage
= Feeds multi-basis, multi-currency accounting
        ↓
ABOR (Accounting Book of Record)
= Official accounting records
= Performance Accounting + Official Accounting
= Source for client reporting, GIPS, regulatory filings
```

### What Triggers a Business Event → Accounting Event
```
Business Event (e.g., trade executed, dividend received, corporate action)
    ↓ tracked in OBOR
Accounting Event triggered (journal entry: debit + credit in subledger)
    ↓ flows into ABOR
```

### Portfolio Valuation Process
1. Month-end: Aladdin "closes the books" — locks a snapshot of all positions and prices
2. Runs **60 quality control checks** on the data
3. Calculates NAV for each portfolio
4. Pairs with official performance figure → client reporting and GIPS
5. NAV Oversight: compares Aladdin NAV vs. fund administrator's figure on T-1 basis

### Official Accounting vs. Performance Accounting
| | Performance Accounting | Official Accounting |
|---|---|---|
| Use | Portfolio valuation, NAV, GIPS | Statutory/regulatory accounting |
| Clients | Asset managers, pensions | Insurance, corporations, asset owners |
| Frequency | Monthly (valuation), daily (NAV oversight) | As required |
| Primary apps | Dashboard (Accounting monitors), Accounting Portal | Aladdin Accounting module |

---

## Module 3.6 — Reconciliation Configuration (Align & PPM)

### Overview
Advanced users can configure how Aladdin performs reconciliations — not just run them. This is done via Align (ruleset editor) and PPM (Process Profile Manager).

### Align — Ruleset Management
- Define matching rules: which fields must match between Aladdin and external source
- Set tolerance thresholds (e.g., position breaks under 100 units are auto-resolved)
- Configure exception categories and priorities
- Rules apply to both asset recon and cash recon workflows

### PPM — Process Profile Manager
- Review overall reconciliation configuration for a portfolio or fund
- Configure which external sources are reconciled against
- Set reconciliation frequency and escalation rules

### Typical Advanced Recon Workflow
```
1. Exception appears in Dashboard recon monitor
2. Analyst investigates via ART (Aladdin Recon Tool)
3. If systemic issue → escalate to Align to update ruleset
4. If configuration issue → update in PPM
5. Re-run historical recon in ART to verify fix
```

---

## Module 3.7 — Derivative Operations: Collateral Management

### Overview
Aladdin manages the full collateral lifecycle for OTC, cleared, and ETD instruments.

### Bilateral OTC Derivatives
```
1. Set up: ISDA Master Agreement + CSA terms captured in Aladdin
2. Daily: AcadiaSoft automated margin call workflow
   → call agreed: use collateral selection tool
   → tool selects cheapest/most liquid eligible position (by haircut, size)
   → instruction sent via SWIFT to custodian
3. Reporting: customizable; files deliverable to Tri-resolve
```

### Cleared Derivatives
```
1. Clearing broker files consumed by Aladdin
2. Reconciliation runs: positions, trades, margin balances, settled/pending net margin
3. Agreed calls → net margin trade auto-booked + SWIFT instruction
4. Disputed calls → view reconciliation detail in Dashboard → resolve manually
```

### Collateral Selection Logic
- System evaluates eligible collateral by: haircut, position size, liquidity
- Selects cheapest-to-deliver eligible position
- Books collateral trade and sends SWIFT instruction automatically

---

## Level 3 Completion Check

You're operating at expert level when you can:
1. Walk through the PM → trader handoff end-to-end and name every app involved
2. Build a what-if scenario in Explore for a pre-trade analysis
3. Explain the difference between IBOR, OBOR, and ABOR in Aladdin's context
4. Describe how BQL translates an investment guideline into a compliance rule
5. Configure a reconciliation ruleset change in Align following a systemic break
6. Explain Aladdin's collateral selection logic for a bilateral margin call
