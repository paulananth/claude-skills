# Cowork Skills

Personal Claude Cowork skills for financial services and investment technology workflows.

## Skills

### `aladdin-training`
Structured curriculum for learning BlackRock Aladdin — from orientation through advanced workflows. Covers Portfolio Management, Risk, Trading, Operations, Accounting, Compliance, Research, and Data modules.

### `aladdinsdk-codebase-navigator`
Navigation guide for the BlackRock AladdinSDK and aladdinsdk-plugin-builder open-source repositories. Helps orient around API bundles, swagger specs, plugin structure, and the core SDK architecture.

## Usage
These skills are loaded into Claude via Cowork. Place each skill folder under `/mnt/skills/user/` in your Cowork environment.
