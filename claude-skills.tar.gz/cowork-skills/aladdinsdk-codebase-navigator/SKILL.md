---
name: aladdinsdk-codebase-navigator
description: >
  Use this skill whenever the user asks about the AladdinSDK or AladdinSDK Plugin Builder
  codebases. Triggers include: questions about where code lives, how the repo is organized,
  what a file or module does, how plugins are structured, where to find API bundles or swagger
  specs, how the core SDK relates to plugins, or any navigation question like "where do I find X"
  or "what does Y do". Also use when the user mentions aladdinsdk, asdk, AGraph, ADCClient,
  plugin bundles, swagger_plugin_bundles, or asdk_agraph_plugin_builder. Use this skill
  proactively — if the user is clearly working in this codebase, apply it without being asked.
---

# AladdinSDK Codebase Navigator

## Overview

Two related BlackRock open-source repos:

| Repo | Local Path | Purpose |
|------|-----------|---------|
| `aladdinsdk` | `C:\work\projects\aladdinsdk` | Core SDK — API client, ADC client, config, auth |
| `aladdinsdk-plugin-builder` | `C:\work\projects\aladdinsdk-plugin-builder` | Builds installable API plugin packages from Swagger specs |

The repos are coupled: the plugin-builder generates packages that aladdinsdk auto-discovers and loads.

---

## aladdinsdk — Repo Structure

```
aladdinsdk/
├── aladdinsdk/               # Main Python package
│   ├── __init__.py           # SDK initialization, version, config bootstrap
│   ├── api/                  # AladdinAPI client — call any Aladdin REST endpoint
│   ├── adc/                  # ADCClient — Snowflake/ADC access (OAuth or JWT)
│   ├── common/               # Shared utilities (auth, errors, logging)
│   ├── config/               # Configuration loading and validation
│   └── storage/              # Local storage / credential helpers
├── resources/
│   └── sample_code_snippets/ # sample_api_calls.md, sample_adc_calls.md
├── test/                     # Unit tests mirroring package structure
├── requirements.txt
└── pyproject.toml
```

### Key entry points
- **API calls**: `from aladdinsdk.api.client import AladdinAPI`
- **ADC/Snowflake**: `from aladdinsdk.adc.client import ADCClient`
- **Config**: lives in `aladdinsdk/config/` — YAML-based, supports env overrides

### Plugin discovery
The SDK auto-scans installed Python packages for compatible plugins (packages named `asdk_plugin_*`). No manual registration needed — install the package and the APIs become available.

---

## aladdinsdk-plugin-builder — Repo Structure

```
aladdinsdk-plugin-builder/
├── asdk_agraph_plugin_builder.py   # Main entry point — reads specs, calls openapi-generator
├── resources/
│   ├── openapi-generator-cli.jar   # Bundled openapi-generator v6.6.0
│   ├── swagger_plugin_bundles/     # One folder per domain = one plugin package
│   │   ├── accounting/
│   │   ├── analytics/
│   │   ├── clients/
│   │   ├── compliance/
│   │   ├── data/
│   │   ├── investment_operations/
│   │   ├── investment_research/
│   │   ├── platform/
│   │   ├── portfolio/
│   │   ├── portfolio_management/
│   │   └── trading/
│   └── templates/                  # Mustache/Jinja templates for codegen
├── pyproject.toml
└── setup.cfg
```

### Domain → Plugin package mapping
Each subfolder under `swagger_plugin_bundles/` maps to a pip-installable plugin:

| Folder | pip package |
|--------|-------------|
| `accounting` | `asdk_plugin_accounting` |
| `trading` | `asdk_plugin_trading` |
| `investment_research` | `asdk_plugin_investment_research` |
| `portfolio_management` | `asdk_plugin_portfolio_management` |
| *(etc.)* | `asdk_plugin_<domain>` |

### How the builder works
1. Reads Swagger/OpenAPI JSON specs from `swagger_plugin_bundles/<domain>/`
2. Calls `openapi-generator-cli.jar` (v6.6.0) via subprocess to generate Python API clients
3. Wraps generated clients with `api_registry.py` and `domain_apis_list.json`
4. Produces a pip-installable package with `pyproject.toml`

**To add or update a plugin**: edit the Swagger specs under the relevant domain folder. Changes require Aladdin API stakeholder approval.

**To run the builder**:
```bash
python asdk_agraph_plugin_builder.py
# Optional flags:
# -oj / --openapi-generator-cli-jar   Path to alternate jar
```

### GitHub Actions
The `.github/` directory contains a workflow that automatically runs the builder for every tag pushed to the repo.

---

## How the two repos connect

```
swagger specs (plugin-builder/resources/swagger_plugin_bundles/)
        ↓
asdk_agraph_plugin_builder.py  →  generates Python API clients
        ↓
pip install asdk_plugin_<domain>
        ↓
aladdinsdk auto-discovers installed plugins
        ↓
AladdinAPI("SomeAPI") works without any extra setup
```

---

## API Usage Guide

### Basic API call pattern
```python
from aladdinsdk.api.client import AladdinAPI

api = AladdinAPI("TradeAPI")                          # instantiate with API name
response = api.get("/trades/{id}", id="T_123")        # GET
response = api.post("/trades:filter", {"query": {}})  # POST with body
```

The API name string (e.g. `"TradeAPI"`) must match the name in the plugin's `api_registry.py`. Names come from the `x-aladdin-spec-id` field in the Swagger spec.

### Response handling
By default, responses are deserialized to codegen objects. To get raw JSON:
```python
response = api.post("/trades:filter", body, _deserialize_to_object=False)
```

### Pagination
For endpoints that return large result sets:
```python
response = api.post(
    "/trainJourneys:filter",
    req_body,
    _asdk_pagination_options={
        "page_size": 5,
        "number_of_pages": 10,
        "timeout": 300,    # seconds
        "interval": 2      # seconds between calls
    }
)
# response is a list — one item per page
```

Config equivalents (in YAML):
```yaml
API:
  PAGINATION:
    MAX_PAGE_SIZE: 10
    MAX_PAGES: 5
    TIMEOUT: 300
    INTERVAL: 2
```

### Long-Running Operations (LRO)
For async operations that poll for completion:
```python
response = api.call_lro_api(
    "/longRunningOperation",
    body,
    status_check_interval=10,  # poll every 10s (default)
    timeout=300                 # give up after 300s (default)
)
```

### Retry logic
```yaml
API:
  RETRY:
    wait_fixed: 2          # seconds between retries
    stop_after_attempt: 3  # max attempts
    stop_after_delay: 7    # or stop after N seconds total
```

### Batch processing
Run multiple API calls sequentially or in parallel:
```python
from aladdinsdk.common.batch.action import SDKActionBuffer, SDKAction

buffer = SDKActionBuffer(max_size=10)
buffer.append_action(SDKAction(api.post, "/trades:filter", body1))
buffer.append_action(SDKAction(api.post, "/trades:filter", body2))

buffer.run_sequential(interval=1)   # or run_parallel(max_workers=4)

for uid, result in buffer.get_response_map().items():
    print(uid, result)
```

### Additional HTTP headers
```python
api = AladdinAPI("TradeAPI", api_additional_http_headers={
    "X-Subscription-Key": "abc123",
    "X-Correlation-Token": "xyz789"
})
# or per-request:
api.get("/trades", _asdk_additional_request_headers={"X-Subscription-Key": "abc123"})
```

### URL rewriting (enterprise API gateway)
```python
api = AladdinAPI("TradeAPI", api_url_rewrite_options={
    "find": r"^https://\w+\.blackrock\.com/api/",
    "replace": "https://api.acmecorp.com/aladdin/"
})
```

### Data transformation utilities
```python
from aladdinsdk.common.exports import export_to_csv   # also: json, xlsx, pkl
# See: resources/sample_code_snippets/sample_data_transformations.py
```

---

## Typical Use Cases

| Use case | Plugin | API | Pattern |
|----------|--------|-----|---------|
| Filter trade orders | `asdk_plugin_trading` | `OrderAPI` | POST `/orders:filter` |
| Get trade records | `asdk_plugin_trading` | `TradeAPI` | GET/POST |
| Portfolio group lookup | `asdk_plugin_portfolio` | `PortfolioGroupAPI` | GET |
| CID read/write | `asdk_plugin_portfolio_management` | `CIDReaderAPI` / `CIDWriterAPI` | GET / POST |
| Cash ladder data | `asdk_plugin_portfolio_management` | `CashLadderAPI` | POST |
| ESG/Climate data | `asdk_plugin_analytics` | `EsgDataAPI` / `ClimateAPI` | GET/POST |
| Compliance violations | `asdk_plugin_compliance` | `ViolationAPI` | GET/POST |
| Research notes | `asdk_plugin_investment_research` | `ResearchNoteAPI` | GET/POST |
| Corporate actions | `asdk_plugin_investment_operations` | `CorporateActionAPI` | GET/POST |
| User/group management | `asdk_plugin_platform` | `UserAPI` / `UserGroupAPI` | GET/POST |
| ADC / Snowflake query | core (`aladdinsdk`) | `ADCClient` | `query_sql()` |
| ADC write | core (`aladdinsdk`) | `ADCClient` | `write_frame()` |

### ADC (Snowflake) usage
```python
from aladdinsdk.adc.client import ADCClient

client = ADCClient()
df = client.query_sql('SELECT * FROM "CASH_ENTRY" LIMIT 10')
client.write_frame(df=df, table_name="TARGET_TABLE")
```

### S3 storage
```python
from aladdinsdk.storage.s3 import S3Client
s3 = S3Client()
s3.upload_file(filename="/path/to/file.txt", key="file.txt")
s3.download_file(key="file.txt", filename="/path/to/out.txt")
```

### Studio notifications (SMTP/Push)
```python
from aladdinsdk.common.notifications.studio_notifications import send_studio_smtp_notification
send_studio_smtp_notification(
    recipients=["user@blackrock.com"],
    subject="Job complete",
    message="Pipeline finished successfully"
)
```

---

## Authentication

### Two supported auth types: `Basic Auth` (default) and `OAuth`

Set via config file or environment variable `ASDK_API__AUTH_TYPE`.

---

### Basic Auth
Requires an API Token registered via Aladdin Studio UI.

```yaml
API:
  AUTH_TYPE: Basic Auth
  TOKEN: <api_token_from_studio>
USER_CREDENTIALS:
  USERNAME: <your_username>
  PASSWORD: <your_password>       # not recommended in plain text
  # Better: ENCRYPTED_PASSWORD_FILEPATH or use keyring (local mode)
```

**Local mode / keyring** (recommended for dev):
- Set `RUN_MODE: local` and install `keyring`
- On first API call with missing password, SDK prompts and stores in OS credential manager (e.g. macOS Keychain)
- Service name in keyring: `ASDK-PASSWORD-{defaultWebServer}`

---

### OAuth — two flows

#### Flow 1: `client_credentials`
```yaml
API:
  AUTH_TYPE: OAuth
  AUTH_FLOW_TYPE: client_credentials
  OAUTH:
    AUTH_SERVER_URL: <oauth_server_url>
    CLIENT_ID: <client_id>
    CLIENT_SECRET: <client_secret>
```

#### Flow 2: `refresh_token`
```yaml
API:
  AUTH_TYPE: OAuth
  AUTH_FLOW_TYPE: refresh_token
  OAUTH:
    AUTH_SERVER_URL: <oauth_server_url>
    CLIENT_ID: <client_id>
    CLIENT_SECRET: <client_secret>
    REFRESH_TOKEN: <refresh_token>
```

**Generating a refresh token locally** (use `aladdinsdk-cli`):
1. Create an OAuth app in Studio UI with a localhost callback URI: `http://localhost:<PORT>`
2. Run `aladdinsdk-cli` → select OAuth → Refresh Token Flow
3. Provide client ID, secret, and port — SDK opens browser for auth and outputs the token

#### OAuth with pre-fetched access token
```yaml
API:
  AUTH_TYPE: OAuth
  OAUTH:
    ACCESS_TOKEN: <direct_access_token>
```

---

### ADC (Snowflake) Authentication

#### OAuth (default for ADC)
```yaml
ADC:
  CONN:
    AUTHENTICATOR: oauth
    OAUTH:
      ACCESS_TOKEN: <token>   # optional if Studio app handles token via TokenAPI
```

In Studio compute environments, `ADCClient` auto-fetches OAuth tokens from Aladdin's TokenAPI — no manual token needed if the user is logged into Studio UI.

#### RSA Keys / snowflake_jwt
```yaml
ADC:
  CONN:
    AUTHENTICATOR: snowflake_jwt
    RSA:
      PRIVATE_KEY_FILEPATH: /path/to/rsa_key.p8
      PRIVATE_KEY_PASSPHRASE: <passphrase>
    ACCOUNT: <snowflake_account_url>
    ROLE: <role>
    WAREHOUSE: <warehouse>
    DATABASE: <database>
    SCHEMA: <schema>
```

**Key generation steps:**
```bash
mkdir Keys && cd Keys
openssl genrsa 2048 | openssl pkcs8 -topk8 -inform PEM -out rsa_key.p8
openssl rsa -in rsa_key.p8 -pubout -out rsa_key.pub
# Then register the public key in Snowflake:
# CALL ALADDINDB.PUBLIC.UPDATE_PUB_KEY_SP('<pub key contents without BEGIN/END lines>', 'KEY1');
```

---

### Config priority (lowest → highest)
1. Default config YAML file
2. User config YAML file (`ASDK_USER_CONFIG_FILE`)
3. `ASDK_` environment variables (use `__` for nesting, e.g. `ASDK_API__TOKEN`)
4. Inline parameters in code

**Bootstrap CLI:**
```bash
aladdinsdk-cli   # interactive wizard to generate a config file
```

**Inspect active config:**
```python
import aladdinsdk
aladdinsdk.config.print_current_user_config()
```

---

## Permissions Required

### API (Basic Auth)
- An **API Token** must be registered in Aladdin Studio UI under a Project
- The token is scoped to the user's Aladdin permissions — only APIs the user has access to will work
- User credentials (`USERNAME` + `PASSWORD`) must be valid Aladdin credentials

### API (OAuth)
- An **OAuth Application** must be created in Aladdin Studio UI under a Project
- The app must be configured with the correct **scopes** — each API endpoint requires specific scopes from its Swagger spec security definitions
- `AGRAPH_SCOPES_ENABLED=True` (default) — SDK automatically requests scopes from the Swagger spec on token generation
- For Refresh Token flow: the OAuth app in Studio must include the localhost callback URI used during token generation
- The authenticated user must have Aladdin entitlements for the APIs being called

### ADC (Snowflake)
- **OAuth**: User must be authenticated in Aladdin Studio UI; ADC OAuth client app must be configured in Studio
- **RSA/JWT**: Public key must be registered in Snowflake via `UPDATE_PUB_KEY_SP` stored procedure
- Required Snowflake connection details: `ACCOUNT`, `ROLE`, `WAREHOUSE`, `DATABASE`, `SCHEMA`
- The Snowflake `ROLE` must have SELECT/INSERT privileges on the tables being accessed

### Studio Notifications
- Requires valid API credentials (Basic Auth or OAuth)
- For OAuth, notification-related scopes must be included in the OAuth app configuration

### S3 Storage
- Access Key ID and Secret Access Key must be sourced from an S3 Storage Integration created in a Studio Project
- Bucket name is assigned per user/project workspace

---

## How to add a new API

### Step 1 — Get or create the Swagger/OpenAPI spec
Obtain the JSON spec for your new API. It must be an AGraph-format OpenAPI spec.

### Step 2 — Set the required `x-aladdin-spec-id` field
Inside the spec's `info` block, add:
```json
"info": {
  "x-aladdin-spec-id": "agraph.<domain>.<segment>.<api_group>.<version>.<APIName>"
}
```
Example: `agraph.trading.order_management.order.v1.OrderAPI`

This ID controls:
- The Python module path in the generated client
- The registry entry in `api_registry.py`
- **Uniqueness** — same API can appear in multiple plugins, but AladdinSDK picks only one definition. Make the ID unique.

Also ensure endpoint paths include security definitions (used for auth headers in generated client).

### Step 3 — Place the spec in the right domain folder
```
resources/swagger_plugin_bundles/
└── <domain>/                  ← existing domain (e.g. trading, analytics)
    └── your_new_api.swagger.json
```

**File naming convention** (follow existing pattern):
```
<domain>_<segment>_<api_group>_<version>_<api_name>.swagger.json
```
Example: `trading_order_management_order_v1_order_api.swagger.json`

To add to a **new domain** (new plugin package), create a new subfolder:
```
resources/swagger_plugin_bundles/my_new_domain/
```
This will generate a new `asdk_plugin_my_new_domain` package.

> ⚠️ **Approval required**: Any changes to `swagger_plugin_bundles/` must be approved by Aladdin API stakeholders before merging.

### Step 4 — Run the builder locally to test
**Prerequisites**: Python 3.9+, Java (for the openapi-generator jar)

```bash
python asdk_agraph_plugin_builder.py \
  -sb resources/swagger_plugin_bundles/<domain> \
  -tl <output_directory> \
  -pv <plugin_version>

# Optional flags:
# -v / --verbose                  More detailed logs
# -oj / --openapi-generator-cli-jar   Use alternate jar version
```

### Step 5 — Verify generated output
The builder produces:
- API client code under paths derived from the spec ID
- `api_registry.py` — tells AladdinSDK which APIs are available
- `domain_apis_list.json` — domain-level API index
- `pyproject.toml` — packaging config

> ⚠️ Changes to `api_registry.py` or `domain_apis_list.json` must be coordinated with the AladdinSDK project.

### Step 6 — Publish via GitHub Actions
Push a tag to the repo — the CI workflow in `.github/` automatically runs the builder and publishes the plugin package for every tag.

### Step 7 — Install and use
```bash
pip install asdk_plugin_<domain>

# Then in Python — no extra setup needed:
from aladdinsdk.api.client import AladdinAPI
api = AladdinAPI("YourNewAPIName")
response = api.get("/your/endpoint")
```

---

## Common navigation questions

| Question | Answer |
|----------|--------|
| "Where are the API specs?" | `aladdinsdk-plugin-builder/resources/swagger_plugin_bundles/<domain>/` |
| "Where is the API client?" | `aladdinsdk/aladdinsdk/api/` |
| "Where is Snowflake/ADC code?" | `aladdinsdk/aladdinsdk/adc/` |
| "Where is auth/config?" | `aladdinsdk/aladdinsdk/common/` and `aladdinsdk/aladdinsdk/config/` |
| "How do I add a new API?" | Add a Swagger spec to the correct domain folder in plugin-builder, run the builder |
| "How do I use an API?" | Install the plugin, then `AladdinAPI("<APIName>")` |
| "Where are code examples?" | `aladdinsdk/resources/sample_code_snippets/` |
| "Where are tests?" | `aladdinsdk/test/` |
